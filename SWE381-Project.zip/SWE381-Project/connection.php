<?php
$sname = 'localhost';
$uname = 'root';
$pass = 'mysql';
$dbName = '381Project';
$conn = mysqli_connect($sname, $uname, $pass, $dbName);
?>
